Kinematics equations necessary to build up the movement and visualization. Both Forward Kinematics and Inverse Kinematics are required.
The required equations are derived in the pdf document.
https://docs.google.com/viewer?url=https://raw.githubusercontent.com/grzesiek2201/Delta/master/Kinematics%20equations/Delta_Kinematics_for_github.pdf
