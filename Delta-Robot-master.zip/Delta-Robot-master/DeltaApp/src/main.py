import deltagui


if __name__ == '__main__':
    my_gui = deltagui.DeltaGUI()